@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.allianz.com/PricingDetailsService/datamodel")
package com.allianz.pricingdetailsservice.datamodel;
